#include<iostream>
#include<cstdlib>
#include<fstream>
#include<map>
#include "bank.h"
#define MIN 1000
using namespace std;
class Banking
{
  private:
   bank b;
   Account acc;
   int choice;
   string fname,lname;
   long accountNumber;
   float balance;
   float amount;

  public:
  void StartBanking()
  {

    cout<<"***Banking System***"<<endl;
        do
        {
        cout<<"\n\tSelect one option below ";
        cout<<"\n\t1 Open an Account";
        cout<<"\n\t2 Balance Enquiry";
        cout<<"\n\t3 Deposit";
        cout<<"\n\t4 Withdrawal";
        cout<<"\n\t5 Close an Account";
        cout<<"\n\t6 Show All Accounts";
        cout<<"\n\t7 Quit";
        cout<<"\nEnter your choice: ";
        cin>>choice;
            switch(choice)
            {
            case 1:
            cout<<"Enter First Name: ";
            cin>>fname;
            cout<<"Enter Last Name: ";
            cin>>lname;
            cout<<"Enter initil Balance: ";
            cin>>balance;
            acc=b.openAccount(fname,lname,balance);
            cout<<endl<<"Congradulation Account is Created"<<endl;
            cout<<acc<<endl;
            break;
            case 2:
            cout<<"Enter Account Number:";
            cin>>accountNumber;
            b.balanceEnquiry(accountNumber);
            cout<<endl;
            break;
            case 3:
            cout<<"Enter Account Number:";
            cin>>accountNumber;
            cout<<"Enter Balance:";
            cin>>amount;
            b.deposite(accountNumber, amount);
            cout<<endl;
            break;
            case 4:
            cout<<"Enter Account Number:";
            cin>>accountNumber;
            cout<<"Enter Balance:";
            cin>>amount;
            b.withdrawal(accountNumber, amount);
            cout<<endl;
            break;
            case 5:
            cout<<"Enter Account Number:";
            cin>>accountNumber;
            b.closeAccount(accountNumber);
            cout<<endl;
            break;
            case 6:cout<<endl<<"***All  Accounts Detail***"<<endl;
            b.showAllAccount();
            cout<<endl;
            break;
            case 7:cout<<endl<<"Thankyou For Visiting My Project"<<endl;
            break;
            default:cout<<"\nEnter corret choice";
                          exit(0);
            }
        }while(choice!=7);
   }


};

