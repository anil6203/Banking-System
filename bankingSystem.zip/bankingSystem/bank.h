#include<iostream>
#include<cstdlib>
#include<fstream>
#include<map>
#define MIN 1000

using namespace std;

class Account
{
 private:
    int AccountNumber;
    string firstName;
    string lastName;
    float balance;
    static long nextAccountNumber;
public:
    Account(){};
    Account(string fname,string lname,float balance);
    string getFirstName(){return firstName;}
    string getLastName(){return lastName;}
    float getBalance(){return balance;}
    long getAccountNumber(){return AccountNumber;}
    void deposit(float amount);
    void withdrawal(float amount);
    static void setNextAccountNumber(long AccountNumber);
    //static long getNextAccountNumber();
    friend ofstream & operator<<(ofstream & ofs,Account & acc);
    friend ifstream & operator>>(ifstream & ifs,Account & acc);
    friend ostream & operator<<(ostream & os,Account & acc);


};


long Account::nextAccountNumber=180101005;



class bank
{
  private:
  map<long,Account> accounts;
  public:
  bank();
  Account openAccount(string fname,string lname,float balance);
  void balanceEnquiry(long AccountNumber);
  void deposite(long AccountNumber,float amount);
  void withdrawal(long AccountNumber,float amount);
  void closeAccount(long AccountNumber);
  void showAllAccount();
  ~bank();

};




//account class function
void Account::deposit(float Amount)
{
  balance+=Amount;
}



void Account::withdrawal(float amount)
{
  if((balance-amount)<MIN)
  cout<<"\n***Withdrawal cannot be done due to insufficient balance***\n"<<endl;
  else
  balance-=amount;
}


Account::Account(string fname,string lname,float balance)
{
 nextAccountNumber++;
 AccountNumber=nextAccountNumber;
 firstName=fname;
 lastName=lname;
 this->balance=balance;
}



void Account::setNextAccountNumber(long AccountNumber)
{
   nextAccountNumber=AccountNumber;
}


ofstream & operator<<(ofstream & ofs,Account & acc)
{
 ofs<<acc.AccountNumber<<endl;
 ofs<<acc.firstName<<endl;
 ofs<<acc.lastName<<endl;
 ofs<<acc.balance<<endl;
 return ofs;
}


ifstream & operator>>(ifstream & ifs,Account & acc)
{
   ifs>>acc.AccountNumber;
   ifs>>acc.firstName;
   ifs>>acc.lastName;
   ifs>>acc.balance;
   return ifs;
}


ostream & operator<<(ostream & os,Account & acc)
{
   os<<"First Name      : "<<acc.getFirstName()<<endl;
   os<<"Secound Name    : "<<acc.getLastName()<<endl;
   os<<"Account Number  : "<<acc.getAccountNumber()<<endl;
   os<<"Account Balance : "<<acc.getBalance()<<endl;
   return os;
}


 //bank class function
 bank::bank()
 {
   Account account;
   ifstream infile;
   infile.open("bank.txt");
   if(!infile)
   {
    return;
   }
   while(infile)
   {
      infile>>account;
      accounts.insert(pair<long,Account> (account.getAccountNumber(),account));
   }
   Account::setNextAccountNumber(account.getAccountNumber());
   infile.close();
}



Account bank::openAccount(string fname,string lname,float balance)
{
     Account acc(fname,lname,balance);
     accounts.insert(pair<long,Account>(acc.getAccountNumber(),acc));
    ofstream outfile("bank.txt",ios::trunc);
    map<long,Account> ::iterator itr;
    for(itr=accounts.begin();itr!=accounts.end();itr++)
    {
     outfile<<itr->second;
    }
    outfile.close();
    return acc;
}



void bank::balanceEnquiry(long AccountNumber)
{
     map<long,Account> ::iterator itr=accounts.find(AccountNumber);
    try
    {
     if(itr->first!=AccountNumber)
      throw 5;
      else
      {
      cout<<endl<<endl<<"Your Account Details"<<endl;
      cout<<itr->second;
      }
    }
      catch(int x)
      {
       cout<<"Invalid account number!!!!"<<endl;
      }
  }



void bank::deposite(long AccountNumber,float amount)
{
    map<long,Account> ::iterator itr=accounts.find(AccountNumber);
     if(itr->first!=AccountNumber)
     cout<<"Invalid account number!!!!"<<endl;
     else
     {
      itr->second.deposit(amount);
      cout<<endl<<endl<<"Amount is Deposited"<<endl;
      cout<<itr->second;
     }
}


void bank::withdrawal(long AccountNumber,float amount)
{
  map<long,Account> ::iterator itr=accounts.find(AccountNumber);
  if(itr->first!=AccountNumber)
     cout<<"Invalid account number!!!!"<<endl;
     else
     {
    itr->second.withdrawal(amount);
    cout<<endl<<endl<<"Amount Withdrawn"<<endl;
     cout<<itr->second;
     }
}



void bank::closeAccount(long AccountNumber)
{
  map<long,Account> ::iterator itr=accounts.find(AccountNumber);
     if(itr->first!=AccountNumber)
     cout<<endl<<"Invalid account number!!!!"<<endl;
     else
     {
     cout<<endl<<"Account is closed "<<endl<<itr->second;
     accounts.erase(AccountNumber);
     }
}



void bank::showAllAccount()
{
   map<long,Account> :: iterator itr;
   for(itr=accounts.begin();itr!=accounts.end();itr++)
   {
    cout<<endl<<itr->first<<endl<<itr->second<<endl;
   }
}


bank::~bank()
{
    ofstream outfile("bank.txt",ios::trunc);
    map<long,Account> ::iterator itr;
    for(itr=accounts.begin();itr!=accounts.end();itr++)
    {
    outfile<<itr->second;
    }
    outfile.close();
}

