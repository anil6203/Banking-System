#include<iostream>
#include "banking.h"
using namespace std;
int main()
{
 Banking B;
 B.StartBanking();
 return 0;
}

